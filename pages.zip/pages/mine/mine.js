var Bmob = require('../../utils/Bmob-1.6.7.min.js')

Page({

  data: {
    newOpenid:'',
    userInfo:'',
    openid:'',
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    list: [
      { 'id': 0, 'hidden': true }
    ],
    listCon: [
      { 'id': 0, 'hidden': true }
    ]
  },  

  bindRegiser: function () {
    //调用API从本地缓存中获取数据
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)
    var user = new Bmob.User();
    var newOpenid = wx.getStorageSync('openid')
    if (!newOpenid) {
      wx.login({
        success: function (res) {
          user.loginWithWeapp(res.code).then(function (user) {
            var openid = user.get("authData").weapp.openid;
            console.log(user, 'user', user.id, res);
            if (user.get("nickName")) {
              // 第二次访问
              console.log(user.get("nickName"), 'res.get("nickName")');
              wx.setStorageSync('openid', openid)
            } else {
              //保存用户其他信息
              wx.getUserInfo({
                success: function (result) {
                  var userInfo = result.userInfo;
                  var nickName = userInfo.nickName;
                  var avatarUrl = userInfo.avatarUrl;
                  var u = Bmob.Object.extend("_User");
                  var query = new Bmob.Query(u);
                  // 这个 id 是要修改条目的 id，你在生成这个存储并成功时可以获取到，请看前面的文档
                  query.get(user.id, {
                    success: function (result) {
                      // 自动绑定之前的账号
                      result.set('nickName', nickName);
                      result.set("userPic", avatarUrl);
                      result.set("openid", openid);
                      result.save();
                    }
                  });
                }
              });
            }
          }, function (err) {
            console.log(err, 'errr');
          });
        }
      });
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

    bindGetUserInfo: function (e) {
    console.log(e.detail.userInfo)
  },
  bindMybook: function(){
    wx.navigateTo({
      url: '../Mybook/Mybook'
    })
  },

  bindgotoPCRbook: function(){
    wx.navigateTo({
      url: '../PCRbook/PCRbook'
    })
  },

  bindgotoMassbook: function () {
    wx.navigateTo({
      url: '../Massbook/Massbook'
    })
  },

  bindgotoHPLCbook: function () {
    wx.navigateTo({
      url: '../HPLCbook/HPLCbook'
    })
  },

  bindgotoYcbook: function () {
    wx.navigateTo({
      url: '../Ycbook/Ycbook'
    })
  },
  hiddenBtn: function (e) {
    var that = this;
    // 获取事件绑定的当前组件
    var index = e.currentTarget.dataset.index;
    // 获取list中hidden的值
    // 隐藏或显示内容
    that.data.list[index].hidden = !that.data.list[index].hidden;
    that.setData({
      list: that.data.list
    })
  }
})
