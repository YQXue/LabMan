var Bmob = require('../../utils/Bmob-1.6.7.min.js')
var util = require('../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
   booklist:{},
    array: ['8:00am-10:00am', '10:00am-12:00am', '12:00am-2:00pm', '2:00pm-4:00pm', '4:00pm-6:00pm', '6:00pm-8:00pm', '8:00pm-10:00pm', '10:00pm以后'],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    const query = Bmob.Query("PCR");
    query.equalTo("jequipmentname", "==", "HPLC");
    query.order("-createdAt");
    query.limit(20);
    query.find().then(res => {
      console.log(res);
      that.setData({
       booklist:res
      })
    });
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})