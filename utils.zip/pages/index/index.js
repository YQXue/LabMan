//index.js
//获取应用实例
const app = getApp()
var Bmob = require('../../utils/Bmob-1.6.7.min.js')
Page({
  data: {
    motto: 'Hello World',
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo')
  },
  gotoPCR: function(){
    wx.navigateTo({
      url: '../PCR/PCR'
    })
  },
  gotoMass: function () {
    wx.navigateTo({
      url: '../Mass/Mass'
    })
  },
  gotoHPLC: function () {
    wx.navigateTo({
      url: '../HPLC/HPLC'
    })
  },
  gotoYaochuang: function () {
    wx.navigateTo({
      url: '../Yc/Yc'
    })
  },

  onLoad: function () {
 
  } 

}
)