var Bmob = require('../../utils/Bmob-1.6.7.min.js')
var common = require('../../utils/common.js')
var util = require('../../utils/util.js')
var that;
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    array: ['8:00am-10:00am', '10:00am-12:00am', '12:00am-2:00pm', '2:00pm-4:00pm', '4:00pm-6:00pm', '6:00pm-8:00pm', '8:00pm-10:00pm', '10:00pm以后'],//定义全部时间段集合
    timechoosn: '',
    datechoosn: ''
  },

  bindDateChange: function (e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      datechoosn: e.detail.value
    })
  },

  bindPickerTime: function (e) {
    console.log('picker携带改变值为', e.detail.value)
    this.setData({
      timechoosn: e.detail.value
    });
  },

  addPCR: function (event) {
    var timechoosn = event.detail.value.time;
    var datechoosn = event.detail.value.date;
    var name = event.detail.value.name;
    var phonenumber = event.detail.value.phonenumber;
    var groupname = event.detail.value.groupname;
    var notes = event.detail.value.notes
    var that = this;
    if (!name) {
      common.showTip("请填写姓名", "loading");
      return false;
    }
    else if (!phonenumber) {
      common.showTip("请填写手机号码", "loading");
      return false;
    }
    else if (!groupname) {
      common.showTip("请填写课题组", "loading");
      return false;
    }
    else if (!notes) {
      common.showTip("请填写备注", "loading");
      return false
    }
    else {
      const query = Bmob.Query('PCR');
      query.set('jequipmentname', "HPLC")
      query.set('jdate', datechoosn);
      query.set('jtime', timechoosn);
      query.set('jname', name);
      query.set('jphonenumber', phonenumber);
      query.set('jgroupname', groupname);
      query.set('jnotes', notes);
      query.save().then(res => {
        // 成功保存
        common.showModal('预约成功', '感谢使用', function () {
          wx.reLaunch({
            url: '../index/index',
          })
        })
      }).catch(err => {
        console.log(err);
        common.showModal('预约失败，请检查网络连接');
      });
    }
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }

})